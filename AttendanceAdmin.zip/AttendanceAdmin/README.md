# Attendance Admin — Android App

Chairman/Admin ke liye alag app (`com.muhammadipublicschool.attendanceadmin`).
Teacher Attendance system ke Apps Script deployment ka `?action=admin` page load
karti hai.

## Camera fix
Is app mein `MainActivity.java` ke andar WebView ka `onShowFileChooser` khaas
tarah likha gaya hai taake "Take Face Photo" dabate hi seedha camera khule -
generic file-picker nahi. Isay FileProvider ki zaroorat hai (already
`AndroidManifest.xml` aur `res/xml/file_paths.xml` mein set hai).

## Build
Zip GitHub repo mein upload karein, Actions → "Build Android APK" run karein.
APK "Attendance-Admin-APK" artifact mein milega.
